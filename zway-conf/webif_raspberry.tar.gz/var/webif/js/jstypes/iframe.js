"use strict";

function iframe(prm)
{
    iframe.super.constructor.call(this, prm);
}

jstypes.iframe = iframe;

extend(iframe, _base_);

iframe.prototype.mk_label = function (lbl)
{
    iframe.super.mk_label.call(this, lbl, "div");
}

iframe.prototype.mk_data = function (prm)
{
    var el, opt_el;
    var i;


    this.el.data = document.createElement("iframe");

    this.el.data.className += " prm_data";

    this.el.cntr.appendChild(this.el.data);
}

iframe.prototype.chcb = function ()
{
    this.el.data.src = this._value_;
}
