"use strict";

function text_div(prm)
{
    text_div.super.constructor.call(this, prm);
}

jstypes.text_div = text_div;

extend(text_div, _base_);

text_div.prototype.mk_data = function (prm) {
    this.el.data = document.createElement("div");
    if ( prm.ro )
	this.el.cntr.className += " prm_ro";

    mlang_set({ el: this.el.data, el_prop: "title", name: prm.name },
	      { str: prm.web.title });
    this.el.data.className += " prm_data";

    this.el.cntr.appendChild(this.el.data);
}

text_div.prototype.chcb = function ()
{
    this.el.data.innerHTML = this._value_;
}
