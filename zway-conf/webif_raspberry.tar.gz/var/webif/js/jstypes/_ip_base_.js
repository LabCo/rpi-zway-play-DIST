"use strict";

function _ip_base_(prm)
{
    _ip_base_.super.constructor.call(this, prm);
}

extend(_ip_base_, _base_);

_ip_base_.prototype._check_ip = function (ip)
{
    var rex = /^(\d{1,3}\.){3}\d{1,3}$/;
    var a = new Array();
    var str = new String(ip);


    if ( ! rex.test(str) )
	return false;

    a = str.split(".");
    if ( a.length != 4 )
	return false;
    if (( a[0] < 1 ) || ( a[0] > 255 ))
	return false;
    if (( a[1] < 0 ) || ( a[1] > 255 ))
	return false;
    if (( a[2] < 0 ) || ( a[2] > 255 ))
	return false;
    if (( a[3] < 0 ) || ( a[3] > 255 ))
	return false;

    return true;
}
