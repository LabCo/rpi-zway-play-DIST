"use strict";

function select(prm)
{
    select.super.constructor.call(this, prm);
}

jstypes.select = select;

extend(select, _base_);

select.prototype.mk_data = function (prm)
{
    var el, opt_el;
    var i;


    el = document.createElement("select");
    if ( prm.ro ) {
	el.disabled = true;
	this.el.cntr.className += " prm_ro";
    }
    el.name = prm.name;
    el.dataset.prm_name = prm.name;
    mlang_set({ el: el, el_prop: "title", name: prm.name },
	      { str: prm.web.title });

    // Add options elements
    for(i = 0; i < prm.values.length; i++) {
	opt_el = document.createElement("option");
	if ( prm.web.values_titles != undefined ) {
	    mlang_set({ el: opt_el, el_prop: "innerHTML", name: prm.name },
		      { str: prm.web.values_titles, idx: i });
	} else
	    opt_el.innerHTML = prm.values[i];
	opt_el.value = prm.values[i];
	el.appendChild(opt_el);
    }

    el.className += " prm_data";

    this.el.data = el;
    this.el.cntr.appendChild(this.el.data);

    return el;
}

select.prototype.chcb = function ()
{
    var i;


    for(i = 0; i < this._prm.values.length; i++)
	if ( this._value_ == this._prm.values[i] )
	    this.el.data.options[i].selected = true;
}
