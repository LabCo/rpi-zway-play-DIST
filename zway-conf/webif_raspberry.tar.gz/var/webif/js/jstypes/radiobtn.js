"use strict";

function radiobtn(prm)
{
    radiobtn.super.constructor.call(this, prm);
}

jstypes.radiobtn = radiobtn;

extend(radiobtn, _base_);

radiobtn.prototype.mk_data = function (prm)
{
    var el, opt_el;
    var i;
    var data;


    this.el.cntr.appendChild(document.createElement("br"));

    data = document.createElement("div");
    data.className = "prm_data";
    this.el.cntr.appendChild(data);

    this.el.data = [];

    for(i = 0; i < prm.values.length; i++) {
	this.el.data[i] = {}
	this.el.data[i].cntr = document.createElement("div");
	// Create a data element
	this.el.data[i].d = document.createElement("input");
	this.el.data[i].d.type = "radio";
	this.el.data[i].d.name = prm.name;
	this.el.data[i].d.dataset.prm_name = prm.name;
	this.el.data[i].d.value = prm.values[i];
	mlang_set({ el: this.el.data[i].d, el_prop: "title", name: prm.name },
		  { str: prm.web.title });

	if ( prm.ro ) {
	    this.el.data[i].d.disabled = true;
	    this.el.cntr.className += " prm_ro";
	}
	this.el.data[i].cntr.appendChild(this.el.data[i].d);
	// Create a label element
	this.el.data[i].l = document.createElement("span");
	if ( prm.web.values_titles != undefined ) {
	    mlang_set({ el: this.el.data[i].l, el_prop: "innerHTML",
			name: prm.name },
		      { str: prm.web.values_titles, idx: i });
	} else 
	    this.el.data[i].l.innerHTML = prm.values[i];

	/* Attach an event to the label */
	this.el.data[i].l.dataset.idx = i;
	$(this.el.data[i].l).on("click", this, this.label_onclick_event);

	this.el.data[i].cntr.appendChild(this.el.data[i].l);

	data.appendChild(this.el.data[i].cntr);
    }
}

radiobtn.prototype.chcb = function ()
{
    var i;


    for(i = 0; i < this._prm.values.length; i++)
	if ( this._value_ == this._prm.values[i] )
	    this.el.data[i].d.checked = true;
}

// Attach event listeners to a data element
radiobtn.prototype.add_event_listeners = function ()
{
    this.el.cntr.addEventListener("change", this.onchange_event.bind(this));
}

radiobtn.prototype.label_onclick_event = function (ev)
{
    var oref = ev.data;
    var t = ev.target || ev.srcElement;
    var ev;
    var data;


    ev.preventDefault;

    data = oref.el.data;

    data[t.dataset.idx].d.checked = true;
    ev = new Event("change", {bubbles: true});
    data[t.dataset.idx].d.dispatchEvent(ev);
}