"use strict";

function _base_(prm)
{
    var oref = this;


    // the backend stuff for this.value accessor
    this._value_ = prm.value;
    this._value_old_ = undefined;
    // the backend stuff for this.err_msg accessor
    this._err_msg_ = undefined;

    // may be defined in a child object before a call
    if ( this.fl == undefined )
	this.fl = {};
    this.el = {};
    this._prm = prm;

    // See init() method, that must call some methods from the setter
    Object.defineProperty(this, "value", {
	get: this._accessor.bind(this, "__glock_for_value",
				 function () {
				     return oref._value_;
				 }),
	set: this._accessor.bind(this, "__slock_for_value",
				 function (v) {
				     oref._value_old_ = oref._value_;
				     oref._value_ = v;
				     if ( ! oref.verifier() )
					 return;
				     oref.chcb();
				     oref._do_switch_();
				 })
    });
    Object.defineProperty(this, "err_msg", {
	get: this._accessor.bind(this, "__glock_for_err_msg",
				 function () {
				     return oref._err_msg_;
				 }),
	set: this._accessor.bind(this, "__slock_for_err_msg",
				 function (v) {
				     oref.errcb(v);
				 })
    });

    // Set a flag for is_for_submit()
    if ( this.fl.for_submit == undefined ) {
	if ( prm.ro )
	    this.fl.for_submit = 0;
        else
	    this.fl.for_submit = 1;
    }

    // Create a container
    this.mk_cntr(prm);

    // Create a label
    this.mk_label(prm.web.label);

    // Create a data element
    this.mk_data(prm);

    /* Create an info bar */
    this.mk_info(prm.web.info);

    this.add_event_listeners();

    this.err_msg = prm.err_msg;
}

/*
 * This is a wrapper for an accessor functions.
 * It use lock_name property of this object to check recursive
 * calls of an accessor and stop execution in this case with an error
 * message.
 * See object constructor for an example of use.
 */
_base_.prototype._accessor = function (lock_name, fun, v)
{
    var ret;


    if ( this[lock_name] )
	return show_error(sprintf(errmsgs.accessor_recursion,
				  this._prm.name, lock_name));
    this[lock_name] = 1;

    ret = fun(v);

    this[lock_name] = 0;

    return ret;
}

/*
 * TMPL_GROUP is undefined
 * cntr: prm.web.hide ? cntr.style.display = "none" : true;
 * label: For a label we must use mlang_set() _after_ dom element is generated.
 * data: mlang_set() for title
 * info: mlang_set() for innerHTML
 * info: onmouseover/onmouseout
 * this.el.cntr, this.el.label, this.el.data, this.el.info ?
 */
_base_.prototype.tmpl_text = '\
<div id="prm_name_{%TMPL_VAR NAME=name%}" class="parameter prm_type_{%TMPL_VAR NAME=type%} {%TMPL_IF NAME=ro%}prm_ro{%/TMPL_IF%}">\
  {%TMPL_GROUP NAME=web%}\
  <label class="prm_label">{%TMPL_VAR NAME=label%}</label>\
  {%/TMPL_GROUP%}\
\
  {%TMPL_IFDEF NAME=err_msg%}\
    <span class="err_msg">{%TMPL_VAR NAME=err_msg%}</span>\
  {%TMPL_ELSE%}\
    {%TMPL_IF NAME=ro%}\
      <span class="prm_data">{%TMPL_VAR NAME=value%}</span>\
    {%TMPL_ELSE%}\
      <input type="text" name="{%TMPL_VAR NAME=name%}" value="{%TMPL_VAR NAME=value%}"/>\
    {%/TMPL_IF%}\
  {%/TMPL_IFDEF%}\
\
  {%TMPL_GROUP NAME=web%}\
  <div class="prm_info {%TMPL_IF NAME=info_as_tooltip%}tooltip{%/TMPL_IF%}">\
  </div>\
  {%/TMPL_GROUP%}\
</div>';

/*
 * Create a container element.
 */
_base_.prototype.mk_cntr = function (prm, node_name, class_name)
{
    var cntr;


    if ( node_name == undefined )
	node_name = "div";
    if ( class_name == undefined )
	class_name = "parameter";

    cntr = document.getElementById("prm_name_" + prm.name);
    if ( cntr == undefined ) {
	cntr = document.createElement(node_name);
	cntr.id = "prm_name_" + prm.name;
    }
    cntr.className += " " + class_name;
    cntr.className += " prm_type_" + prm.type;

    if ( prm.web.hide )
	cntr.style.display = "none";

    this.el.cntr = cntr;

    // Add an error message container
    this.el.err_msg = document.createElement("div");
    this.el.err_msg.className = "err_msg";
    this.el.cntr.appendChild(this.el.err_msg);

    return cntr;
}

_base_.prototype.mk_info = function (info_str, node_name, class_name)
{
    var info, self;


    if ( info_str == undefined )
	return;

    if ( node_name == undefined )
	node_name = "div";
    if ( class_name == undefined )
	class_name = "prm_info";

    if ( this._prm.web.info_as_tooltip ) {
	class_name += " tooltip";
	self = this;
	this.el.cntr.onmouseover = function () { self.tooltip_show(); };
	this.el.cntr.onmouseout = function () { self.tooltip_hide(); };
    }

    info = document.createElement(node_name);
    info.className = class_name;
    mlang_set({ el: info, el_prop: "innerHTML", name: this._prm_name },
	      { str: info_str });

    this.el.info = info;
    this.el.cntr.appendChild(this.el.info);

    return info;
}

/*
 * Create a label element.
 */
_base_.prototype.mk_label = function (lbl, node_name, class_name)
{
    var label;


    if ( lbl == undefined )
	return;

    if ( node_name == undefined )
	node_name = "label";
    if ( class_name == undefined )
	class_name = "prm_label";

    label = document.createElement(node_name);
    label.className = class_name;
    mlang_set({ el: label, el_prop: "innerHTML", name: this._prm.name },
	      { str: lbl });

    this.el.label = label;
    this.el.cntr.appendChild(this.el.label);

    return label;
}

/*
 * Create a data element.
 */
_base_.prototype.mk_data = function (prm)
{
    var data;


    if ( prm.ro ) {
	data = document.createElement("span");
	this.el.cntr.className += " prm_ro";
    } else {
	data = document.createElement("input");
	data.type = "text";
	data.name = prm.name;
	data.dataset.prm_name = prm.name;
    }

    mlang_set({ el: data, el_prop: "title", name: prm.name },
	      { str: prm.web.title });
    data.className += " prm_data";

    this.el.data = data;
    this.el.cntr.appendChild(this.el.data);

    return data;
}

// Attach event listeners to a data element
_base_.prototype.add_event_listeners = function ()
{
    this.el.data.addEventListener("change", this.onchange_event.bind(this));
}

_base_.prototype.init = function ()
{
    this.chcb();
    if ( ! this._prm.web.switch_no_init )
	this._do_switch_();
}

_base_.prototype.prm_get = function ()
{
    var oref = this;
    var req_uri;


    req_uri = location.pathname + "?act=geta&prm=" + this._prm.name;
    $.getJSON(req_uri, function (data) {
	var str;


	if ( data.err_status != "ok" ) {
	    show_error(sprintf(errmsgs.prm_recv_err,
			       oref._prm.name, data.err_msg));
	    return;
	}

	data = data.data;
	oref.err_msg = data.prms[0].err_msg;
	oref.value = data.prms[0].value;
    });
}

_base_.prototype._showhide_group_by_name = function (gname, act)
{
    var p = get_group_by_name(gname);


    if ( p != undefined )
	if ( act == "show" ) {
	    p.hide = false;
	    p._el.cntr.style.display = "";
	} else if ( act == "hide" ) {
	    p.hide = true;
	    p._el.cntr.style.display = "none";
	}

    return 0;
}

_base_.prototype._showhide_param_by_name = function (pname, act)
{
    var p = get_param_by_name(pname);


    if ( p != undefined )
	if ( act == "show" ) {
	    p.web.hide = false;
	    p._jstype.el.cntr.style.display = "";
	} else if ( act == "hide" ) {
	    p.web.hide = true;
	    p._jstype.el.cntr.style.display = "none";
	}

    return 0;
}

_base_.prototype.hide_group_by_name = function (gname)
{
    this._showhide_group_by_name(gname, "hide");
}

_base_.prototype.show_group_by_name = function (gname)
{
    this._showhide_group_by_name(gname, "show");
}

_base_.prototype.hide_param_by_name = function (pname)
{
    this._showhide_param_by_name(pname, "hide");
}

_base_.prototype.show_param_by_name = function (pname)
{
    this._showhide_param_by_name(pname, "show");
}

// Do not use this.value or any methods call that may cause in
// infinite recursion for this.value setter!
_base_.prototype.do_switch = function (value)
{
    var groups, params;
    var i;


    groups = this._prm._switch[value].hide_groups;
    if ( groups != undefined )
	for(i = 0; i < groups.length; i++)
	    this.hide_group_by_name(groups[i]);

    groups = this._prm._switch[value].show_groups;
    if ( groups != undefined )
	for(i = 0; i < groups.length; i++)
	    this.show_group_by_name(groups[i]);

    params = this._prm._switch[value].hide_params;
    if ( params != undefined )
	for(i = 0; i < params.length; i++)
	    this.hide_param_by_name(params[i]);

    params = this._prm._switch[value].show_params;
    if ( params != undefined )
	for(i = 0; i < params.length; i++)
	    this.show_param_by_name(params[i]);
}

_base_.prototype._do_switch_ = function ()
{
    if ( this._prm._switch != undefined ) {
	if ( this._prm._switch[this._value_] != undefined ) {
	    this.do_switch(this._value_);
	    this.swcb();
	} else if ( this._prm._switch[" _default_ "] != undefined ) {
	    this.do_switch(" _default_ ");
	    this.swcb();
	}
    }
}

_base_.prototype.onchange_event = function (ev)
{
    var t = ev.target || ev.srcElement;


    /* Check that changed element is our element. This is need in a complex
       case. E.g. if we add(with a help of postadd function) into radiobtn
       parameter some string parameter, then changes of the string parameter
       cause onchange event is generated also for radiobtn parameter; and
       without this check we assign a string parameter value to radiobtn
       parameter - what's wrong. */
    if ( t.dataset.prm_name != this._prm.name )
	return;

    this.value = t.value;
}

_base_.prototype.is_for_submit = function ()
{
    if ( this.err_msg == undefined )
	return this.fl.for_submit;
    else
	return false;
}

_base_.prototype.tooltip_show = function ()
{
    var off, base_el;


    if ( this.el.info == undefined )
	return;

    this.el.info.style.display = "block";

    if ( this.el.label != undefined )
	base_el = this.el.label;
    else
	base_el = this.el.cntr;
	
    off = $(base_el).offset();
    off.top += $(base_el).height() + 2;
    $(this.el.info).offset(off);
}

_base_.prototype.tooltip_hide = function ()
{
    if ( this.el.info == undefined )
	return;

    this.el.info.style.display = "none";
}

_base_.prototype.verifier = function ()
{
    return true;
}

_base_.prototype.chcb = function ()
{
    if ( this._prm.ro )
	this.el.data.innerHTML = this._value_;
    else
	this.el.data.value = this._value_;
}

_base_.prototype.swcb = function ()
{
    return true;
}

_base_.prototype.errcb = function (v)
{
    if ( v == this._err_msg_ )
	return;

    this._err_msg_ = v;

    if ( v == undefined )
	this.el.err_msg.style.display = "none";
    else {
	this.el.err_msg.innerHTML = this._prm.name + ": " + v;
	this.el.err_msg.style.display = "block";
    }
}