"use strict";

function ipprefix(prm)
{
    ipprefix.super.constructor.call(this, prm);
}

jstypes.ipprefix = ipprefix;

extend(ipprefix, _ip_base_);

ipprefix.prototype.verifier = function ()
{
    var str = new String(this._value_);
    var a = new Array();


    str = str.replace(/ /g, "");

    a = str.split("/");

    if (( a.length != 2 ) ||
	( ! this._check_ip(a[0]) ) ||
	(( Number(a[1]) < 8 ) || ( Number(a[1]) > 30 ))) {
	this.el.data.classList.add("error");
	return show_error(sprintf(errmsgs.wrong_prm_value,
				  mlang_get_str(this._prm.web.label, this._prm.name),
				  this._prm.name));
    }
    this.el.data.classList.remove("error");

    this.el.data.value = str;
    this._value_ = str;

    return true;
}
