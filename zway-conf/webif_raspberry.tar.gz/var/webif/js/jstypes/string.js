"use strict";

function string(prm)
{
    string.super.constructor.call(this, prm);
}

jstypes.string = string;

extend(string, _base_);
