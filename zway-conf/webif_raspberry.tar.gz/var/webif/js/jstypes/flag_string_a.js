"use strict";

function flag_string_a(prm)
{
    var oref = this;


    this.fl = { for_submit: 0 };
    this.mlstrs = [];

    flag_string_a.super.constructor.call(this, prm);

    if ( prm.web.interval != undefined )
	setInterval(this.prm_get.bind(this), prm.web.interval);
    else
	show_error(sprintf(errmsgs.flag_string_a_interval_isndef, prm.name));
}

jstypes.flag_string_a = flag_string_a;

extend(flag_string_a, flag_string);

