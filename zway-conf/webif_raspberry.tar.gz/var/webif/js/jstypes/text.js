"use strict";

function text(prm)
{
    text.super.constructor.call(this, prm);
}

jstypes.text = text;

extend(text, _base_);

text.prototype.mk_data = function (prm) {
    this.el.cntr.appendChild(document.createElement("br"));

    if ( prm.ro ) {
	this.el.data = document.createElement("pre");
	this.el.cntr.className += " prm_ro";
    } else {
	this.el.data = document.createElement("textarea");
	this.el.data.name = prm.name;
	this.el.data.dataset.prm_name = prm.name;
    }

    mlang_set({ el: this.el.data, el_prop: "title", name: prm.name },
	      { str: prm.web.title });
    this.el.data.className += " prm_data";

    this.el.cntr.appendChild(this.el.data);
}

text.prototype.chcb = function ()
{
    if ( this._prm.ro )
	this.el.data.innerHTML = this._value_;
    else
	this.el.data.value = this._value_;
}
