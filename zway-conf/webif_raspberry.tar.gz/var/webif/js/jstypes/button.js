"use strict";

function button(prm)
{
    this.fl = { for_submit: 0 };

    button.super.constructor.call(this, prm);

    // Attach an event to the data element
    if ( prm.web.submit )
	$(this.el.data).on("click", this, this.but_onclick_event);
}

jstypes.button = button;

extend(button, _base_);

button.prototype.mk_label = function () {}

button.prototype.mk_data = function (prm)
{
    var el, opt_el;
    var i;


    this.el.data = document.createElement("button");
    if ( prm.web.submit )
	this.el.data.type = "submit";
    this.el.data.name = prm.name;
    this.el.data.dataset.prm_name = prm.name;

    mlang_set({ el: this.el.data, el_prop: "innerHTML", name: prm.name },
	      { str: prm.web.label });
    if ( prm.ro ) {
	this.el.data.disabled = true;
	this.el.cntr.className += " prm_ro";
    }

    mlang_set({ el: this.el.data, el_prop: "title", name: prm.name },
	      { str: prm.web.title });
    this.el.data.className += " prm_data";

    this.el.cntr.appendChild(this.el.data);
}

button.prototype.chcb = function ()
{
    this.el.data.value = this._value_;
}

button.prototype.but_onclick_event = function (ev)
{
    var oref = ev.data;
    var t = ev.target || ev.srcElement;
    var groups = [];


    oref.fl.for_submit = 1;

    groups.push({ groups: [ oref._prm._grp ] });

    do_save_conf(groups);
}