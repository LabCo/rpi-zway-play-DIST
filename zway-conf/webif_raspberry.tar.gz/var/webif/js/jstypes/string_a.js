"use strict";

function string_a(prm)
{
    var oref = this;


    this.fl = { for_submit: 0 };

    string_a.super.constructor.call(this, prm);

    setInterval(this.prm_get.bind(this), prm.web.interval);
}

jstypes.string_a = string_a;

extend(string_a, _base_);

string_a.prototype.mk_data = function (prm)
{
    var el, opt_el;
    var i;


    this.el.data = document.createElement("span");
    this.el.data.className = "prm_data";
    mlang_set({ el: this.el.data, el_prop: "title", name: prm.name },
	      { str: prm.web.title });

    this.el.cntr.appendChild(this.el.data);
}

string_a.prototype.chcb = function ()
{
    this.el.data.innerHTML = this._value_;
}
