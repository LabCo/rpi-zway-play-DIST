"use strict";

function flag_string(prm)
{
    this.fl = { for_submit: 0 };
    this.mlstrs = [];

    flag_string.super.constructor.call(this, prm);
}

jstypes.flag_string = flag_string;

extend(flag_string, _base_);

flag_string.prototype.mk_data = function (prm)
{
    var oref = this;


    this.el.data = document.createElement("span");
    this.el.data.className = "prm_data";

    this.el.cntr.appendChild(this.el.data);

    this.mlstrs[1] = mlang_set({ el: this.el.data, el_prop: "title", name: this._prm.name },
			       { str: this._prm.web.title },
			       this.mlstrs[1]);

    return this.el.data;
}

flag_string.prototype.chcb = function ()
{
    var oref = this;


    this.mlstrs[0] = mlang_set({ el: this.el.data, el_prop: "innerHTML",
                                 name: this._prm.name,
                                 cb: function (e) {
                                     var str = mlang_get_str(oref._prm.web.values_styles,
                                                             e.data_name, e.idx);
                                     e.el.style.cssText = str;
                                 } },
                               { str: this._prm.web.values_titles, idx: this._value_ },
                               this.mlstrs[0]);
    mlang_change_for_entry(this.mlstrs[0]);
}
