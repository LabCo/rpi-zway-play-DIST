"use strict";

function checkbox(prm)
{
    checkbox.super.constructor.call(this, prm);
}

jstypes.checkbox = checkbox;

extend(checkbox, _base_);

checkbox.prototype.mk_data = function (prm)
{
    var el, opt_el;
    var i;


    if ( prm.values.length < 2 ) {
	// TODO: normal error handling
	show_error(sprintf(errmsgs.checkbox_too_few_values, prm.name));
	return;
    }
    this.el.data = document.createElement("input");
    this.el.data.type = "checkbox";
    this.el.data.name = prm.name;
    this.el.data.dataset.prm_name = prm.name;
    this.el.data.value = prm.values[1];
    if ( prm.ro ) {
	this.el.data.disabled = true;
	this.el.cntr.className += " prm_ro";
    }

    mlang_set({ el: this.el.data, el_prop: "title", name: prm.name },
	      { str: prm.web.title });
    this.el.data.className += " prm_data";

    this.el.cntr.appendChild(this.el.data);
}

checkbox.prototype.chcb = function ()
{
    if ( this._value_ == this._prm.values[1] )
	this.el.data.checked = true;
}

// Attach event listeners to a data element
checkbox.prototype.add_event_listeners = function ()
{
    checkbox.super.add_event_listeners.call(this);

    /* Attach an event to the label */
    this.el.label.addEventListener("click", this.label_onclick_event.bind(this));
}

checkbox.prototype.onchange_event = function (ev)
{
    var t = ev.target || ev.srcElement;


    /* See _base_.prototype.onchange_event() for an explanation */
    if ( t.dataset.prm_name != this._prm.name )
	return;

    if ( t.checked )
	this.value = this._prm.values[1];
    else
	this.value = this._prm.values[0];
}

checkbox.prototype.label_onclick_event = function (ev)
{
    if ( this.el.data.checked )
	this.el.data.checked = false;
    else
	this.el.data.checked = true;

    ev = new Event("change", {bubbles: true});
    this.el.data.dispatchEvent(ev);
}