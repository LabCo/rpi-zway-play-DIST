"use strict";

function password(prm)
{
    this.fl = { for_submit: 0 };

    password.super.constructor.call(this, prm);

    $(this.el.data).on("focus", this, this.passwd_onfocus_event);
}

jstypes.password = password;

extend(password, _base_);

password.prototype.mk_data = function (prm)
{
    var data;


    data = document.createElement("input");
    data.type = "password";
    data.name = prm.name;
    data.dataset.prm_name = prm.name;

    mlang_set({ el: data, el_prop: "title", name: prm.name },
	      { str: prm.web.title });
    data.className += " prm_data";

    this.el.data = data;
    this.el.cntr.appendChild(this.el.data);

    return data;
}

password.prototype.chcb = function ()
{
    this.fl.for_submit = 1;
    this.el.data.value = this._value_;
}

password.prototype.passwd_onfocus_event = function (ev)
{
    var t = ev.target || ev.srcElement;


    t.value = "";
}
