"use strict";

/* The collection of error messages according to the selected language.
   Filled by set_page_prms() */
var errmsgs = {};
var jstypes = {};
/*
 * For a fast access to groups and parameters.
 * See _make_page_prms() and _make_page_grp().
 */
var grps_hash = {};
var prms_hash = {};


function show_srv_error()
{
    var err_el = document.getElementById("err_div");


    err_el.innerHTML = srverr;
    err_el.style.display = "block";
}

function show_error(msg)
{
    alert(msg);
}

function set_cookie(c_name, value, exdays)
{
    var exdate = new Date();
    var c_val;


    exdate.setDate(exdate.getDate() + exdays);
    c_val = escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
    document.cookie = c_name + "=" + c_val;
}

function get_cookie(name) {
    var cookie = " " + document.cookie;
    var search = " " + name + "=";
    var setStr;
    var offset = 0;
    var end = 0;


    if (cookie.length > 0) {
        offset = cookie.indexOf(search);
        if (offset != -1) {
            offset += search.length;
            end = cookie.indexOf(";", offset)
            if (end == -1)
		end = cookie.length;
            setStr = unescape(cookie.substring(offset, end));
        }
    }

    return setStr;
}

function get_param_by_name(name)
{
    return prms_hash[name];
}

function get_group_by_name(name)
{
    return grps_hash[name];
}
