"use strict";

function make_page()
{
    var cntr;


    if ( srverr != "" ) {
	show_srv_error();
	document.getElementById("cntr").style.display = "none";
	return;
    }

    if ( grps[0].mlang_langs != undefined )
	mlang_init(grps[0].mlang_langs);

    if ( grps[0].params != undefined )
	_make_page_prms(document.getElementById("ctrls_cntr"),
			grps[0].params, grps[0]);

    set_page_prms(grps[0]);

    cntr = document.getElementById("cntr");
    _make_page_grp(cntr, grps[0].groups);
    if ( grps[0].params != undefined )
	_init_prms(grps[0].params);
    _init_grp(grps[0].groups);
}

