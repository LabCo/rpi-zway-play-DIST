"use strict";

var mlang_cur_lang;
// This array is not for items deleting.
// Dumb deleting may cause an addition problem (see e_idx use in mlang_set()).
var mlang_strs = [];


function _mlang_set_lang(new_lang)
{
    mlang_cur_lang = new_lang;
    set_cookie("WEBIF_IFLANG", mlang_cur_lang, 365);
}

function mlang_set_lang(new_lang)
{
    _mlang_set_lang(new_lang);
    mlang_change();
}

/*
 * what.name is a group or parameter name, which is used only for
 * a error reporting (to see which parameter or group contains a bad string).
 * e_idx is mlang_strs array index. If it is undefined, then
 * new entry is created; else - an existing entry is modified.
 */
function mlang_set(what, mlstr, e_idx)
{
    var e = {};


    if ( mlstr.str == undefined )
	return undefined;

    e.data_name= what.name;
    e.el = what.el;
    e.el_prop = what.el_prop;
    e.cb = what.cb;
    e.str = mlstr.str;
    e.idx = mlstr.idx;

    e.el[e.el_prop] = mlang_get_str(e.str, e.data_name, e.idx);

    if ( e_idx == undefined )
	e_idx = mlang_strs.push(e) - 1;
    else {
	if ( mlang_strs[e_idx] == undefined )
	    return show_error(sprintf(errmsgs.mlang_no_str_with_idx, e_idx));
	else
	    mlang_strs[e_idx] = e;
    }

    return e_idx;
}

/*
 * gp_name is a group or parameter name, which is used only for
 * a error reporting (to see which parameter or group contains a bad string).
 */
function mlang_get_str(mlstr, gp_name, idx)
{
    if ( mlstr == undefined )
	return "";

    if ( typeof(mlstr) == "string" )
	return mlstr;
    else if ( Array.isArray(mlstr) ) {
	if ( mlstr[Number(idx)] == undefined )
	    return show_error(sprintf(errmsgs.mlang_cant_get_str_with_idx,
				      idx, JSON.stringify(mlstr), gp_name));
	return mlstr[Number(idx)];
    } else if ( typeof(mlstr) == "object" ) {
	if ( mlang_cur_lang == undefined )
	    return show_error(errmsgs.mlang_curlang_is_undef);

	if ( mlstr[mlang_cur_lang] == undefined )
	    return show_error(sprintf(errmsgs.mlang_gp_not_support_lang,
				      gp_name, mlang_cur_lang));

	if ( typeof(mlstr[mlang_cur_lang]) == "string" )
	    return mlstr[mlang_cur_lang];
	else if ( Array.isArray(mlstr[mlang_cur_lang]) ) {
	    if ( mlstr[mlang_cur_lang][Number(idx)] == undefined )
		return show_error(sprintf(errmsgs.mlang_cant_get_str_with_idx,
					  idx,
					  JSON.stringify(mlstr[mlang_cur_lang]),
					  gp_name));

	    return mlstr[mlang_cur_lang][Number(idx)];
	}
    }

    show_error(sprintf(errmsgs.mlang_wrong_str_type, typeof(mlstr), gp_name));
}

function mlang_set_lang_click_hdlr(l)
{
    return function () { mlang_set_lang(l); };
}

function mlang_make_bar(langs)
{
    var i;
    var el, cntr_el;


    cntr_el = document.getElementById("lang_bar");

    for(i = 0; i < langs.length; i++) {
	if ( i ) {
	    el = document.createTextNode(" | ");
	    cntr_el.appendChild(el);
	}
	el = document.createElement("span");
	el.onclick = mlang_set_lang_click_hdlr(langs[i]);
	el.innerHTML = String(langs[i]).toUpperCase();
	cntr_el.appendChild(el);
    }
}

function mlang_init(langs)
{
    var l;


    if ( typeof(langs) != "object" )
	return;

    if ( langs.length == 0 ) {
	show_error(errmsgs.mlang_no_lang_defined);
	return;
    }

    /* Set default lang */
    mlang_cur_lang = langs[0];
    if ( langs.length > 1 ) {
	/* If more than 1 lang is defined, then create a langbar and get a
	 * saved lang from the cookie.
	 */
	mlang_make_bar(langs);
	l = get_cookie("WEBIF_IFLANG");
	if ( l != undefined )
	    mlang_cur_lang = l;
    }
    _mlang_set_lang(mlang_cur_lang);
}

/*
 * e_idx is mlang_strs array index.
 */
function mlang_change_for_entry(e_idx)
{
    var e;


    if ( e_idx == undefined )
	return;

    e = mlang_strs[e_idx];
    if ( e == undefined )
	return show_error(sprintf(errmsgs.mlang_no_str_with_idx, e_idx));

    e.el[e.el_prop] = mlang_get_str(e.str, e.data_name, e.idx);

    if (( e.cb != undefined ) && ( typeof(e.cb) == "function" ))
	e.cb(e);
}

function mlang_change()
{
    var i, len;


    for(i = 0, len = mlang_strs.length; i < len; i++) {
	mlang_change_for_entry(i);
    }
}
