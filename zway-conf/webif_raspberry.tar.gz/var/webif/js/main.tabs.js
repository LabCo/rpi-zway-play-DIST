"use strict";

function make_tabs(grps, tabs_id, tabs_data_id)
{
    var tabs, tab_cntr, tab;
    var tabs_data, tab_data_cntr, tab_data;
    var i;


    tabs = document.getElementById(tabs_id);
    tabs_data = document.getElementById(tabs_data_id);

    for(i = 0; i < grps.length; i++) {
	grps[i]._el = {}
	// Create a tab
	tab_cntr = document.createElement("td");
	tab_cntr.style.position = "relative";
	tab_cntr.style.zIndex = "2";
	tabs.appendChild(tab_cntr);
	grps[i]._el.cntr = tab_cntr;

	tab = document.createElement("div");
	tab.className = tabs_id + " grp_tab_label tab";
	if ( i == 0 )
	    tab.className += " tab_sel";
	tab.onclick = function (event) {
	    tab_click(event, tabs_id, tabs_data_id);
	};
	mlang_set({ el: tab, el_prop: "innerHTML", name: grps[i].name },
		  { str: grps[i].label });
	tab_cntr.appendChild(tab);
	grps[i]._el.label = tab;

	if ( grps[i].err_msg != undefined ) {
	    tab = document.createElement("div");
	    tab.className = "err_msg";
	    tab.innerHTML = grps[i].err_msg;
	    tab_cntr.appendChild(tab);
	}
	
	// Create a tab data
	tab_data_cntr = document.createElement("div");
	tab_data_cntr.id = "grp_name_" + grps[i].name;
	tab_data_cntr.className = tabs_data_id + " tab_data";
	if ( i == 0 )
	    tab_data_cntr.className += " tab_data_sel";
	tabs_data.appendChild(tab_data_cntr);

	/* Create a tab info div */
	if ( grps[i].info != undefined ) {
	    grps[i]._el.info = document.createElement("div");
	    grps[i]._el.info.className = "grp_tab_info";
	    mlang_set({ el: grps[i]._el.info, el_prop: "innerHTML",
			name: grps[i].name },
		      { str: grps[i].info });
	    tab_data_cntr.appendChild(grps[i]._el.info);
	}

	/* Create a tab groups and parameters container */
	tab_data = document.createElement("div");
	tab_data.className = "grp_tab_data";
	tab_data_cntr.appendChild(tab_data);
	
	/* Create a tab controls */
	if (( grps[i].params != undefined ) &&
	    ( ! grps[i].params_after_groups ))
	    _make_page_prms(tab_data, grps[i].params, grps[i]);

	/* Create a tab data content */
	if ( grps[i].groups != undefined )
	    if ( grps[i].groups_are_tabs ) {
		tab_data.className += " grp_tab_data_is_tabs";
		tab = document.getElementById("tmpl_tabs_cntr").cloneNode(true);
		tab.id = "";
		tab_data.appendChild(tab);
		$("#tmpl_tabs", tab)[0].id = "tabs_" + grps[i].name;
		$("#tmpl_tabs_data", tab)[0].id = "tabs_data_" + grps[i].name;

		make_tabs(grps[i].groups, "tabs_" + grps[i].name,
			  "tabs_data_" + grps[i].name);
	    } else {
		_make_page_grp(tab_data, grps[i].groups);
	    }

	/* Create a tab controls */
	if (( grps[i].params != undefined ) &&
	    ( grps[i].params_after_groups ))
	    _make_page_prms(tab_data, grps[i].params, grps[i]);
    }
}

function make_page()
{
    if ( srverr != "" ) {
	show_srv_error();
	document.getElementById("cntr").style.display = "none";
	return;
    }

    if ( grps[0].mlang_langs != undefined )
	mlang_init(grps[0].mlang_langs);

    if ( grps[0].params != undefined )
	_make_page_prms(document.getElementById("ctrls_cntr"),
			grps[0].params, grps[0]);

    set_page_prms(grps[0]);

    make_tabs(grps[0].groups, "tabs_1", "tabs_data_1");
    if ( grps[0].params != undefined )
	_init_prms(grps[0].params);
    _init_grp(grps[0].groups);
}

