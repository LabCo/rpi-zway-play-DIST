"use strict";

function prm_postadd_prm_fw_lastver_num()
{
    var el;


    this.el.data.parentNode.removeChild(this.el.data);
    this.el.cntr.style.display = "none";

    el = document.querySelector("#prm_name_prm_fw_ver_ctrl .prm_data div");
    el.appendChild(document.createTextNode(" ("));
    el.appendChild(this.el.data);
    el.appendChild(document.createTextNode(")"));
}

function prm_postadd_prm_fw_ver_num()
{
    var el;


    this.el.data.parentNode.removeChild(this.el.data);
    this.el.cntr.style.display = "none";

    el = $("#prm_name_prm_fw_ver_ctrl .prm_data div")[1];
    el.appendChild(this.el.data);

    this.el.data.onclick = function () {
	get_param_by_name("prm_fw_ver_ctrl")._jstype.value = "specific";
    };
    el.querySelector("input").onchange = function () {
	el.querySelectorAll("input")[1].focus();
    }
}

function prm_postadd__upi()
{
    this.swcb = function () {
	if ( this._value_ == "-1" ) {
	    if (( this._value_old_ != undefined ) &&
		( this._value_ != this._value_old_ )) {
		get_param_by_name("_upi_label")._jstype.el.cntr.style.display = "none";
		get_param_by_name("_upi_desc")._jstype.el.cntr.style.display = "none";
		get_param_by_name("_upi")._jstype.el.cntr.style.display = "none";
		get_param_by_name("_upi_finished")._jstype.el.cntr.style.display = "block";
		get_param_by_name("_upi_error")._jstype.el.cntr.style.display = "none";
		get_param_by_name("_upi_but")._jstype.el.cntr.style.display = "block";
	    }
	} else if ( this._value_ == "-2" ) {
	    if (( this._value_old_ != undefined ) &&
		( this._value_ != this._value_old_ )) {
		get_param_by_name("_upi_label")._jstype.el.cntr.style.display = "none";
		get_param_by_name("_upi_desc")._jstype.el.cntr.style.display = "none";
		get_param_by_name("_upi")._jstype.el.cntr.style.display = "none";
		get_param_by_name("_upi_finished")._jstype.el.cntr.style.display = "none";
		get_param_by_name("_upi_error")._jstype.el.cntr.style.display = "block";
		get_param_by_name("_upi_but")._jstype.el.cntr.style.display = "block";
	    }
	} else
	    document.getElementById("cntr").style.display = "none";
    }
    this.chcb = function () {
	var p;
	var pp, msg = "", idx;


	idx = this._value_.indexOf(" ");
	if ( idx == -1 )
	    pp = this._value_;
	else {
	    pp = this._value_.substr(0, idx);
	    msg = this._value_.substr(idx + 1);
	}
	p = get_param_by_name("_changelog");
	if ( pp != "-1" ) {
	    /* Clear the changelog at the start of upgrading
	     * This is only need for a case where we get an upgrade after
	     * finished upgrade without a page refresh.
	     */
	    if ( this._value_old_ == "-1" )
		p._jstype.value = "";

	    this.el.data.style.width = pp;
	    this.el.data.innerHTML = "";
	    get_param_by_name("_upi_desc")._jstype.value = msg;

	    if (( p != undefined ) && ( p._jstype.value == "" ))
		p._jstype.prm_get();
	}
	if ( pp == "-2" ) {
	    this._value_ = "-2";
	}
    }
}

function prm_postadd__upi_but()
{
    this.el.data.onclick = function () {
	location.reload(true);
    }
}
