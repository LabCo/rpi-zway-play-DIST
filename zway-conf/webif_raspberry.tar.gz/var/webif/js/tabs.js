"use strict";

function _tab_change(t_el, t_id, tdata_id)
{
    var $tabs = $("." + t_id + ".tab", document.getElementById(t_id));
    var $tab_data = $("." + tdata_id + ".tab_data",
		      document.getElementById(tdata_id));
    var i;
    var len;


    if ( ! $(t_el).hasClass("tab") )
	return;

    $tabs.removeClass("tab_sel");
    $tab_data.removeClass("tab_data_sel");

    len = $tabs.length;
    for(i = 0; i < len; i++) {
	if ( t_el == $tabs[i] ) {
            $tabs.eq(i).addClass("tab_sel");
            $tab_data.eq(i).addClass("tab_data_sel");
	}
    }
}

function tab_click(ev, t_id, tdata_id, tab_callback)
{
    var t = ev.target || ev.srcElement;


    _tab_change(t, t_id, tdata_id);

    if ( tab_callback != undefined )
	tab_callback();
}
