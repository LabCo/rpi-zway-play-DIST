"use strict";

function set_page_prms(group)
{
    var i;


    mlang_set({ el: document, el_prop: "title", name: group.name },
	      { str: group.title });
    mlang_set({ el: document.getElementById("__caption_div"),
		el_prop: "innerHTML", name: group.name },
	      { str: group.caption });

    // Get multilangual error messages
    for(i in group) {
	if ( i.substr(0, 7) == "errmsg_" ) {
	    mlang_set({ el: errmsgs, el_prop: i.substr(7), name: i },
		      { str: group[i] });
	}
    }
}

/*
 * group is used only for backreference to it from a parameter
 */
function _make_page_prms(cntr, prms, group)
{
    var i;


    for(i = 0; i < prms.length; i++) {
	if ( jstypes[prms[i].type] == undefined ) {
	    show_error(sprintf(errmsgs.type_is_not_defined, prms[i].type));
	    continue;
	}

	prms[i]._jstype = new jstypes[prms[i].type](prms[i]);
	prms[i]._grp = group;
	prms_hash[prms[i].name] = prms[i];

	// Do not append this parameter on the page, If it already exists
	// on the page.
	if ( prms[i]._jstype.el.cntr.parentNode == undefined )
	    cntr.appendChild(prms[i]._jstype.el.cntr);
	if ( window["prm_postadd_" + prms[i].name] != undefined )
	    if (( prms[i].web.use_postadd_func == undefined ) ||
		( prms[i].web.use_postadd_func ))
		window["prm_postadd_" + prms[i].name].call(prms[i]._jstype);
    }
}

function _make_page_grp(cntr, groups)
{
    var i;
    var grp_div, e;


    for(i = 0; i < groups.length; i++) {
	grp_div = document.getElementById("grp_name_" + groups[i].name);
	if ( grp_div == undefined ) {
	    grp_div = document.createElement("div");
	    grp_div.id = "grp_name_" + groups[i].name;
	    cntr.appendChild(grp_div);
	}
	grp_div.className = "group";
	groups[i]._el = {};
	groups[i]._el.cntr = grp_div;
	groups[i]._el.parent = cntr;
	if ( groups[i].label != undefined ) {
	    groups[i]._el.label = document.createElement("div");
	    groups[i]._el.label.className = "grp_label";
	    mlang_set({ el: groups[i]._el.label, el_prop: "innerHTML",
			name: groups[i].name },
		      { str: groups[i].label });
	    grp_div.appendChild(groups[i]._el.label);
	}
	if ( groups[i].err_msg != undefined ) {
	    e = document.createElement("div");
	    e.className = "err_msg";
	    e.innerHTML = groups[i].err_msg;
	    grp_div.appendChild(e);
	    continue;
	}
	grps_hash[groups[i].name] = groups[i];

	/* Create a group info div */
	if ( groups[i].info != undefined ) {
	    groups[i]._el.info = document.createElement("div");
	    groups[i]._el.info.className = "grp_info";
	    mlang_set({ el: groups[i]._el.info, el_prop: "innerHTML",
			name: groups[i].name },
		      { str: groups[i].info });
	    grp_div.appendChild(groups[i]._el.info);
	}

	if ( groups[i].hide )
	    grp_div.style.display = "none";

	/* Create a group data div */
	if (( groups[i].params != undefined ) ||
	    ( groups[i].groups != undefined )) {
	    groups[i]._el.data = document.createElement("div");
	    groups[i]._el.data.className = "grp_data";
	    grp_div.appendChild(groups[i]._el.data);
	}

	if (( groups[i].params != undefined ) &&
	    ( ! groups[i].params_after_groups ))
	    _make_page_prms(groups[i]._el.data, groups[i].params, groups[i]);

	if ( groups[i].groups != undefined )
	    _make_page_grp(groups[i]._el.data, groups[i].groups);

	if (( groups[i].params != undefined ) &&
	    ( groups[i].params_after_groups ))
	    _make_page_prms(groups[i]._el.data, groups[i].params, groups[i]);
    }
}

function _init_prms(prms)
{
    var i;


    for(i = 0; i < prms.length; i++) {
	/* jstype is undefined if group or parameter getter error is occured */
	if ( prms[i]._jstype != undefined )
	    prms[i]._jstype.init();
    }
}

function _init_grp(groups)
{
    var i;


    for(i = 0; i < groups.length; i++) {
	if ( groups[i].params != undefined )
	    _init_prms(groups[i].params);

	if ( groups[i].groups != undefined )
	    _init_grp(groups[i].groups);
    }
}

function _make_post_data(pdata, groups)
{
    var i, j;


    for(i = 0; i < groups.length; i++) {
	if ( groups[i].hide )
	    continue;
	if ( groups[i].params != undefined )
	    for (j = 0; j < groups[i].params.length; j++) {
		/* jstype is undefined if group or parameter getter error
		 * is occured
		 */
		if (( groups[i].params[j].web.hide ) ||
		    ( groups[i].params[j]._jstype == undefined ) ||
		    ( ! groups[i].params[j]._jstype.is_for_submit() ))
		    continue;

		pdata[groups[i].params[j].name] = groups[i].params[j]._jstype.value;
	    }
	if ( groups[i].groups != undefined )
	    if ( ! _make_post_data(pdata, groups[i].groups) )
		return false;
    }

    return true;
}   

function post_url(url, post_data)
{
  var myForm = document.createElement("form");
  myForm.method="post" ;
  myForm.action = url ;
  for (var k in post_data) {
    var myInput = document.createElement("input") ;
    myInput.setAttribute("name", k) ;
    myInput.setAttribute("value", post_data[k]);
    myForm.appendChild(myInput) ;
  }
  document.body.appendChild(myForm) ;
  myForm.submit() ;
  document.body.removeChild(myForm) ;
}

function do_save_conf(groups)
{
    var post_data = {"act": "set"};

    if ( ! _make_post_data(post_data, groups) )
	return;

    /*
    // this does not handle errors correclty
    $.ajax({
	url: "main.cgi",
	type: "post",
	traditional: true,
	data: post_data,
	success: function () {
	    location.reload();
	}
    });
    */

    post_url("main.cgi", post_data);
}

function save_conf()
{
    do_save_conf(grps);
}
