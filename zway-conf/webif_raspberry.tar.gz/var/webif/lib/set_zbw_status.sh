#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#

read FLAG

if [[ $FLAG -eq 0 ]]; then
    touch /etc/zbw/flags/no_connection
    /etc/init.d/zbw_connect stop
else
    rm -f /etc/zbw/flags/no_connection
    /etc/init.d/zbw_connect start
fi
