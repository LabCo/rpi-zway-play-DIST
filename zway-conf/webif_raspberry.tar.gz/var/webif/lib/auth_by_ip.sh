#!/bin/bash
#

function prefix_len_to_int()
{
    local len=$1
    local bitpos
    local p_int
    local bit

    bitpos=31
    p_int=0
    for((; bitpos >= 0; bitpos--, len--)); do
        if [[ $len -gt 0 ]]; then
            bit=1
        else
            bit=0
        fi
        (( p_int += (bit << bitpos) ))
    done

    echo $p_int
}

function ip_to_int()
{
    local ip_part
    local ip_part_int
    local ip_int
    local i

    ip_part=$1
    ip_int=0
    for((i = 0; i < 4; i++)); do
        ip_part_int=${ip_part##*.}
        ip_part=${ip_part%.*}
        (( ip_int += (ip_part_int << i*8) ))
    done

    echo $ip_int
}

P=`ip a | sed -nre 's/^ +inet (([0-9]+\.){3}[0-9]+\/[0-9]+) .+$/\1/; T end; p; :end'`
[[ $? -ne 0 ]] && exit 1

ADDR_INT=`ip_to_int $REMOTE_ADDR`

for PREFIX in $P; do
    IP_INT=`ip_to_int ${PREFIX%/*}`
    MASK_INT=`prefix_len_to_int ${PREFIX#*/}`

    if [[ $(( ADDR_INT & MASK_INT )) -eq $((IP_INT & MASK_INT)) ]]; then
	echo admin
	exit
    fi
done

echo 
