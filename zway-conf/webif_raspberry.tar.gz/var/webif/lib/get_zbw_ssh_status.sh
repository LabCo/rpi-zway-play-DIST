#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#
#

if [[ -e /etc/zbw/flags/forward_ssh ]]; then
    echo 1
else
    echo 0
fi

true
