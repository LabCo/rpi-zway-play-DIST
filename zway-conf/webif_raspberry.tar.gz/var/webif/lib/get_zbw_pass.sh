#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#
#

P=`cat /etc/zbw/passwd`
if [[ $? -ne 0 ]]; then
    exit 1
fi

if [[ -z $P ]]; then
    echo
else
    # output a fake password.
    # js password type doesn't rely on a password value,
    # we just must indicate that some password exist.
    echo 123456
fi

true
