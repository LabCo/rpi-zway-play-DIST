#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type

read PASS

echo -n $PASS | base64 -w0 > /etc/zbw/passwd
echo 8083 > /etc/zbw/local_port