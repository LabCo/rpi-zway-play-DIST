#!/bin/bash

ZWAY_UPIF=/tmp/z-way_upgrading_progress

[[ ! -f $ZWAY_UPIF ]] && echo -1 && exit 0

exec 3<$ZWAY_UPIF

read P <&3
read I <&3

exec 3<&-

echo "$P $I"
