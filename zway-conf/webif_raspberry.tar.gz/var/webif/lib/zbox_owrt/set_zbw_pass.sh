#!/bin/sh
#
# Get:
#  $1 - parameter name
#  $2 - parameter type

read PASS

echo -n $PASS | base64 | awk 'BEGIN { N = "" }; { N = N $1 }; END { print N};' > /etc/zbw/passwd
echo 8083 > /etc/zbw/local_port
