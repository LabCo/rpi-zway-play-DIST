#!/bin/sh
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#

read VAL

if [[ x"$VAL" = x"" ]]; then
    echo Wrong timezone name >&2
    exit 1
fi
if echo "$VAL" | grep -E '\/\.\.$|^\.\.\/|\/\.\.\/|^\/|\/$' >/dev/null 2>&1; then
    echo Wrong timezone name . >&2
    exit 1
fi

echo $VAL > /etc/timezone
ln -sf /usr/share/zoneinfo/$VAL /etc/localtime