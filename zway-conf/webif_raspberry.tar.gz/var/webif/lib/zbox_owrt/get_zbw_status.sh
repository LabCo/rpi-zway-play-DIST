#!/bin/sh
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#
#

if [[ -e /etc/zbw/flags/no_connection ]]; then
    echo 0
else
    echo 1
fi

true
