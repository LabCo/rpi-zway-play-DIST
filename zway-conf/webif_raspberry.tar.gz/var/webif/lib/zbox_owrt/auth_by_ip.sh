#!/bin/sh
#

ip_to_int()
{
    local ip_part
    local ip_part_int
    local ip_int
    local i

    ip_part=$1
    ip_int=0
    for i in `seq 0 3`; do
        ip_part_int=${ip_part##*.}
        ip_part=${ip_part%.*}
        ip_int=$((ip_int + (ip_part_int << i*8)))
    done

    echo $ip_int
}

P=`ifconfig | sed -nre 's/^[[:space:]]+inet addr:([0-9.]+).+Mask:([0-9.]+)[[:space:]]*$/\1 \2/; T end; p; :end'`
[[ $? -ne 0 ]] && exit 1

ADDR_INT=`ip_to_int $REMOTE_ADDR`

for ADDR in $P; do
    IP_INT=`ip_to_int ${ADDR%/*}`
    MASK_INT=`ip_to_int ${ADDR#*/}`

    if [[ $(( ADDR_INT & MASK_INT )) -eq $((IP_INT & MASK_INT)) ]]; then
	echo admin
	exit
    fi
done

echo 
