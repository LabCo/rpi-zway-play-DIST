#!/bin/sh
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#

read FLAG

if [[ $FLAG -eq 0 ]]; then
    rm -f /etc/zbw/flags/forward_ssh
else
    touch /etc/zbw/flags/forward_ssh
fi

/etc/init.d/zbw_connect restart
