#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#
# Env:
#  IFACE - interface name
#

if [[ x"$IFACE" = x"" ]]; then
    echo
    exit 0
fi

PRG='
BEGIN {
    IP="";
    IPMASK="";

    NETMASK["255.255.255.252"]=30;
    NETMASK["255.255.255.248"]=29;
    NETMASK["255.255.255.240"]=28;
    NETMASK["255.255.255.224"]=27;
    NETMASK["255.255.255.192"]=26;
    NETMASK["255.255.255.128"]=25;
    NETMASK["255.255.255.0"]=24;
    NETMASK["255.255.254.0"]=23;
    NETMASK["255.255.252.0"]=22;
    NETMASK["255.255.248.0"]=21;
    NETMASK["255.255.240.0"]=20;
    NETMASK["255.255.224.0"]=19;
    NETMASK["255.255.192.0"]=18;
    NETMASK["255.255.128.0"]=17;
    NETMASK["255.255.0.0"]=16;
    NETMASK["255.254.0.0"]=15;
    NETMASK["255.252.0.0"]=14;
    NETMASK["255.248.0.0"]=13;
    NETMASK["255.240.0.0"]=12;
    NETMASK["255.224.0.0"]=11;
    NETMASK["255.192.0.0"]=10;
    NETMASK["255.128.0.0"]=9;
    NETMASK["255.0.0.0"]=8;
    IF="";
}

END {
    print IP "/" NETMASK[IPMASK];
}

/^iface/ {
    IF=$2;
}

IF == ENVIRON["IFACE"] && ! /^#/ && $1 == "address" {
    IP=$2
}

IF == ENVIRON["IFACE"] && ! /^#/ && $1 == "netmask" {
    IPMASK=$2
}
'

awk "$PRG" /etc/network/interfaces