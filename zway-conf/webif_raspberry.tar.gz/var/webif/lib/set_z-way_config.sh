#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type

read VAL

sed -i "/^\(--$PARAM_NAME\) .*/d" /data/Z-Way/Z-Way.conf

if [ "$VAL" != "" ]
then
	echo "--$PARAM_NAME $VAL" >> /data/Z-Way/Z-Way.conf
fi

if [ "$1" = "lang" ]
then
        echo $VAL | ../lib/set_webif_config_file.sh webif_lang
fi