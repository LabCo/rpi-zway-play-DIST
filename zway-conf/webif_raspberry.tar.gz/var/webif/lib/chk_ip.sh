#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type

read DEFGW

if ! echo $DEFGW | grep -qE '^([0-9]+\.){3}[0-9]+$'; then
    echo Wrong ip >&2
    exit 1
fi

for((i = 0; i < 4; i++)); do
    NUM=${DEFGW%%.*}
    DEFGW=${DEFGW#*.}

    if [[ $NUM -lt 0 || $NUM -gt 255 ]]; then
	echo Wrong ip >&2
	exit 1
    fi
done