#!/bin/bash

PRG='
BEGIN {
    PARAM="";
}

END {
    print PARAM;
}

$1 == "--" PARAM_NAME {
    PARAM = $2;
}
'

awk -v PARAM_NAME=$PARAM_NAME "$PRG" /data/Z-Way/Z-Way.conf
