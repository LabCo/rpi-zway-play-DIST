#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#
# Env:
#  IFACE - interface name
#

if [[ x"$IFACE" = x"" ]]; then
    echo
    exit 0
fi

PATH=$PATH:/sbin:/usr/sbin

ifup $IFACE