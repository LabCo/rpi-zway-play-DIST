#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#
# Env:
#  IFACE - interface name
#

if [[ x"$IFACE" = x"" ]]; then
    echo
    exit 0
fi

read IPPREFIX

IP=${IPPREFIX%/*}
IPMASK=${IPPREFIX##*/}
case $IPMASK in
    30)
	IPMASK="255.255.255.252";
	;;
    29)
	IPMASK="255.255.255.248";
	;;
    28)
	IPMASK="255.255.255.240";
	;;
    27)
	IPMASK="255.255.255.224";
	;;
    26)
	IPMASK="255.255.255.192";
	;;
    25)
	IPMASK="255.255.255.128";
	;;
    24)
	IPMASK="255.255.255.0";
	;;
    23)
	IPMASK="255.255.254.0";
	;;
    22)
	IPMASK="255.255.252.0";
	;;
    21)
	IPMASK="255.255.248.0";
	;;
    20)
	IPMASK="255.255.240.0";
	;;
    19)
	IPMASK="255.255.224.0";
	;;
    18)
	IPMASK="255.255.192.0";
	;;
    17)
	IPMASK="255.255.128.0";
	;;
    16)
	IPMASK="255.255.0.0";
	;;
    15)
	IPMASK="255.254.0.0";
	;;
    14)
	IPMASK="255.252.0.0";
	;;
    13)
	IPMASK="255.248.0.0";
	;;
    12)
	IPMASK="255.240.0.0";
	;;
    11)
	IPMASK="255.224.0.0";
	;;
    10)
	IPMASK="255.192.0.0";
	;;
    9)
	IPMASK="255.128.0.0";
	;;
    8)
	IPMASK="255.0.0.0";
	;;
esac

PRG='
/^#/ b
/^iface[[:space:]]+__IFACE__/ b process
b

:process
a \
	address __IP__
a \
	netmask __IPMASK__
:_process
n
/^#/ b _process
/^iface[[:space:]]/ b
/^[[:space:]]*address[[:space:]]/ d
/^[[:space:]]*netmask[[:space:]]`/ d
b _process'

PRG=`echo "$PRG" | sed -e "s/__IFACE__/$IFACE/; s/__IP__/$IP/; s/__IPMASK__/$IPMASK/"`

sed -i -re "$PRG" /etc/network/interfaces