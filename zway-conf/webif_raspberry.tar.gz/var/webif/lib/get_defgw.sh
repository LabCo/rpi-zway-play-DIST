#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type


PRG='
BEGIN {
    DEFGW="";

    IF="";
}

END {
    print DEFGW;
}

/^iface/ {
    IF=$2;
}

IF != "" && ! /^#/ && $1 == "gateway" && DEFGW == "" {
    DEFGW=$2
}
'

awk "$PRG" /etc/network/interfaces