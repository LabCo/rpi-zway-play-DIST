#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#
# Env:
#  IFACE - interface name
#

if [[ x"$IFACE" = x"" ]]; then
    echo
    exit 0
fi

read IPADDR

PRG='
/^#/ b
/^iface[[:space:]]+__IFACE__/ b process
b

:process
a \
	address __IP__
:_process
n
/^#/ b _process
/^iface[[:space:]]/ b
/^[[:space:]]*address[[:space:]]/ d
b _process'

PRG=`echo "$PRG" | sed -e "s/__IFACE__/$IFACE/; s/__IP__/$IPADDR/;"`

sed -i -re "$PRG" /etc/network/interfaces