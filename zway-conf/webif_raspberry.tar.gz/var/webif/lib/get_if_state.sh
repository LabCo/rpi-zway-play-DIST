#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#
# Env:
#  IFACE - interface name
#

if [[ x"$IFACE" = x"" ]]; then
    echo
    exit 0
fi

FLAGS=`ip a show dev $IFACE | head -n 1 | grep -Eo '<.+>'`
MSG=""

if echo $FLAGS | grep -qE '[<,]UP[,>]'; then
    MSG="Up "
else
    MSG="Down "
fi

if echo $FLAGS | grep -qE '[<,]NO-CARRIER[,>]'; then
    MSG="(link DOWN)"
elif echo $FLAGS | grep -qvE '[<,]LOWER_UP[,>]'; then
    MSG="(link DOWN)"
fi

echo $MSG