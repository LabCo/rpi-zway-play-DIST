#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#
# Env:
#  IFACE - interface name
#

if [[ x"$IFACE" = x"" ]]; then
    echo
    exit 0
fi

PRG='
BEGIN {
    MODE="";
    IF="";
}

END {
    if ( MODE == "dhcp" )
        print "0";
    else if ( MODE == "static" )
        print "1";
}

/^iface/ {
    IF=$2;
    if ( IF == ENVIRON["IFACE"] )
        MODE=$4;
}
'

awk "$PRG" /etc/network/interfaces
