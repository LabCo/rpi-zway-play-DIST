#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#

read VAL

echo $VAL > /proc/sys/net/ipv4/ip_forward

PRG='
/^net\.ipv4\.ip_forward[= ]/ b replace_line
$ a\
net.ipv4.ip_forward=__FWDFLAG__
b

:replace_line
s/^.+$/net.ipv4.ip_forward=__FWDFLAG__/
:until_end
n
b until_end
'


PRG=`echo "$PRG" | sed -e "s/__FWDFLAG__/$VAL/;"`

sed -i -re "$PRG" /etc/sysctl.conf