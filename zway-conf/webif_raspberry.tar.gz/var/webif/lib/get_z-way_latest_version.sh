#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#
#

BOXTYPE=`cat /etc/z-way/box_type` || exit 1

V=`wget -q http://z-way.z-wave.me/z-way/$BOXTYPE/latest/VERSION -O -`
[[ $? -ne 0 ]] && exit 1

echo $V | awk '{ print $1 " " $3; }'

