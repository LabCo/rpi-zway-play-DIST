#!/bin/bash
#
# Get:
#  $1 - group name
#


ZWAY_UPIF=/tmp/z-way_upgrading_progress
ZWAY_CHANGELOG=/tmp/z-way_cur_changelog


get_cur_changelog()
{
    local PRG


    PRG='
/^[0-9]{2}\.[0-9]{2}\.[0-9]{4} v/ b p
b
:p p
n
/^[0-9]{2}\.[0-9]{2}\.[0-9]{4} v/ b p_last
b p
:p_last p
n
/^[0-9]{2}\.[0-9]{2}\.[0-9]{4} v/ q
b p_last'

  wget --quiet -O- http://razberry.z-wave.me/z-way-server/ChangeLog |
    sed -nre "$PRG" > $ZWAY_CHANGELOG
}

# execute the update process in the background
if [[ -z $2 ]]; then
    echo -e "0%\nInstaller downloading" > $ZWAY_UPIF

    # Expect prm_fw_ver_ctrl and prm_fw_ver_num
    while read NAME VAL; do
	eval "export $NAME=$VAL"
    done

    nohup setsid $0 $1 run >/dev/null 2>&1 &
    exit 0
fi

sleep 5s
echo -e "2%\nInstaller downloading" > $ZWAY_UPIF

export ZWAY_UPIF

FNAME=`mktemp`
BOXTYPE=`cat /etc/z-way/box_type` || exit 1

get_cur_changelog

# Update z-way
if [[ $prm_fw_ver_ctrl == "last" ]]; then
    wget -4 http://z-way.z-wave.me/z-way/$BOXTYPE/latest/install -O $FNAME
    [[ $? -ne 0 ]] && exit 1
    echo -e "5%\nInstaller starting" > $ZWAY_UPIF

    chmod u+x $FNAME
    $FNAME || exit 1
elif [[ $prm_fw_ver_ctrl == "specific" ]]; then
    prm_fw_ver_num=`echo $prm_fw_ver_num | sed -e 's/ //g'`
    wget -4 http://z-way.z-wave.me/z-way/$BOXTYPE/$prm_fw_ver_num/install -O $FNAME
    if [[ $? -ne 0 ]]; then
        echo -e "-2\nDownloading error" > $ZWAY_UPIF
        exit 1
    fi
    echo -e "5%\nInstaller starting" > $ZWAY_UPIF

    chmod u+x $FNAME
    $FNAME || exit 1
else
    rm -f $FNAME
    echo "wrong parameter value: $prm_fw_ver_ctrl" >&2
    exit 1
fi
echo -e "100%\nFinish" > $ZWAY_UPIF

rm -f $FNAME $ZWAY_UPIF $ZWAY_CHANGELOG

true
