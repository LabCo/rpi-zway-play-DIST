#!/bin/bash

while read VAR VAL; do
    eval "$VAR=\$VAL";
done

PRG='
x
/^iface/ q
x
/^iface +__IFACE__/ b process
b

:process
n
h
:proc
/^iface / b
s/^(\W+address) +.+$/\1 __IP__/
s/^(\W+netmask) +.+$/\1 __NETMASK__/
s/^(\W+gateway) +.+$/\1 __DEFGW__/
n
b proc'

PRG=`echo "$PRG" | sed -e "s/__IFACE__/$1/; s/__IP__/$ip/; s/__NETMASK__/$netmask/; s/__DEFGW__/$defgw/"`

sed -i -re "$PRG" /etc/network/interfaces