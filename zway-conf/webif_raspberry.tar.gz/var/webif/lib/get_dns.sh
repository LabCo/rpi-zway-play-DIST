#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type


PRG='
BEGIN {
    DNS="";
}

END {
    print DNS;
}

/^nameserver/ {
    DNS=$2;
}
'

awk "$PRG" /etc/resolv.conf