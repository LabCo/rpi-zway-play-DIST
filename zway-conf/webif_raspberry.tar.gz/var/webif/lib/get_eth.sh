#!/bin/bash

PRG='
BEGIN {
    IP="";
    NETMASK="";
    DEFGW="";
    MODE="";

    IF="";
}

END {
    print "ip " IP;
    print "ipmask " NETMASK;
    print "gw_ip " DEFGW;
    if ( MODE == "dhcp" )
        print "ifmode 0";
    else if ( MODE == "static" )
        print "ifmode 1";
}

/^iface/ {
    IF=$2;

    if ( IF == ENVIRON["IFACE"] )
        MODE=$4;
}

IF == ENVIRON["IFACE"] && ! /^#/ && $1 == "address" {
    IP=$2
}

IF == ENVIRON["IFACE"] && ! /^#/ && $1 == "netmask" {
    NETMASK=$2
}

IF == ENVIRON["IFACE"] && ! /^#/ && $1 == "gateway" {
    DEFGW=$2
}
'

awk "$PRG" /etc/network/interfaces