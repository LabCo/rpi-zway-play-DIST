#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#
#

cat /proc/sys/net/ipv4/ip_forward