#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#
# Env:
#  IFACE - interface name
#

if [[ x"$IFACE" = x"" ]]; then
    echo
    exit 0
fi

read IPMASK

PRG='
/^#/ b
/^iface[[:space:]]+__IFACE__/ b process
b

:process
a \
	netmask __IPMASK__
:_process
n
/^#/ b _process
/^iface[[:space:]]/ b
/^[[:space:]]*netmask[[:space:]]/ d
b _process'

PRG=`echo "$PRG" | sed -e "s/__IFACE__/$IFACE/; s/__IPMASK__/$IPMASK/"`

sed -i -re "$PRG" /etc/network/interfaces