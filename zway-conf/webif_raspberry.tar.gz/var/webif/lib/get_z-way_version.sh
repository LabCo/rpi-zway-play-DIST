#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#
#

V=`cat /etc/z-way/VERSION`
[[ $? -ne 0 ]] && exit 1

echo $V | awk '{ print $1 " " $3; }'

exit 0

# the old stuff
V=`cat /data/Z-Way/Z-Way.ver`
[[ $? -ne 0 ]] && exit 1

echo $V | awk 'NR == 1 { print "rev_id " $1} NR == 2 {print "rev_date " strftime("%F", $1)}'
