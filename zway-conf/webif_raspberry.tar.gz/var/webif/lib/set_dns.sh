#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type

read IPADDR

PRG='
/^#/ b
$ a \
nameserver __IPADDR__
/^nameserver / d'

PRG=`echo "$PRG" | sed -e "s/__IPADDR__/$IPADDR/;"`

sed -i -re "$PRG" /etc/resolv.conf
