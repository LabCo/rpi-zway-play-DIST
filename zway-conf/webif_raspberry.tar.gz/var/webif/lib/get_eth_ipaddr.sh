#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#
# Env:
#  IFACE - interface name
#

if [[ x"$IFACE" = x"" ]]; then
    echo
    exit 0
fi

PRG='
BEGIN {
    IP="";
    IF="";
}

END {
    print IP;
}

/^iface/ {
    IF=$2;
}

IF == ENVIRON["IFACE"] && ! /^#/ && $1 == "address" {
    IP=$2
}

'

awk "$PRG" /etc/network/interfaces