#!/bin/bash

export webif_if=$2
if [[ $1 == "get" ]]; then
    eval $3 $2 | while read VAR VAL; do
	echo $VAR $VAL
	done
elif [[ $1 == "set" ]]; then
    while read VAR VAL; do
	eval "$VAR=\$VAL";
    done
    ifdown $2
    echo -e "ip $ip\nnetmask $netmask\ndefgw $defgw" | $3 $2
    ifup $2
fi
