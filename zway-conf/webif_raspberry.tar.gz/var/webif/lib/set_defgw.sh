#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type

read DEFGW

PRG='
function ip_to_int(ip)
{
    split(ip, ipp, /\./);
    ip_int = lshift(ipp[1], 24) + lshift(ipp[2], 16) + lshift(ipp[3], 8);
    ip_int += ipp[4];
    return ip_int;
}

function set_defgw_if(def)
{
    if ( IF != "" ) {
        ip_int=ip_to_int(IP);
        if ( and(ip_int, IPMASK_INT) == and(DEFGW_INT, IPMASK_INT) )
            if ( IPMASK_INT > DEFGW_IF_IPMASK_INT ) {
                DEFGW_IF=IF;
                DEFGW_IF_IPMASK_INT=IPMASK_INT;
            }
    }
}

BEGIN {
    DEFGW_INT=ip_to_int(ENVIRON["webif_defgw"]);
    IP="";
    IPMASK_INT=0;
    IF="";
    DEFGW_IF_IPMASK_INT=0;

    NETMASK_INT["255.255.255.252"]=4294967292;
    NETMASK_INT["255.255.255.248"]=4294967288;
    NETMASK_INT["255.255.255.240"]=4294967280;
    NETMASK_INT["255.255.255.224"]=4294967264;
    NETMASK_INT["255.255.255.192"]=4294967232;
    NETMASK_INT["255.255.255.128"]=4294967168;
    NETMASK_INT["255.255.255.0"]=4294967040;
    NETMASK_INT["255.255.254.0"]=4294966784;
    NETMASK_INT["255.255.252.0"]=4294966272;
    NETMASK_INT["255.255.248.0"]=4294965248;
    NETMASK_INT["255.255.240.0"]=4294963200;
    NETMASK_INT["255.255.224.0"]=4294959104;
    NETMASK_INT["255.255.192.0"]=4294950912;
    NETMASK_INT["255.255.128.0"]=4294934528;
    NETMASK_INT["255.255.0.0"]=4294901760;
    NETMASK_INT["255.254.0.0"]=4294836224;
    NETMASK_INT["255.252.0.0"]=4294705152;
    NETMASK_INT["255.248.0.0"]=4294443008;
    NETMASK_INT["255.240.0.0"]=4293918720;
    NETMASK_INT["255.224.0.0"]=4292870144;
    NETMASK_INT["255.192.0.0"]=4290772992;
    NETMASK_INT["255.128.0.0"]=4286578688;
    NETMASK_INT["255.0.0.0"]=4278190080;
    DEFGW_IF="";
}

END {
    set_defgw_if();
    print DEFGW_IF;
}

/^iface/ {
    set_defgw_if()
   IF=$2;
}

! /^#/ && $1 == "address" {
    IP=$2
}

! /^#/ && $1 == "netmask" {
    IPMASK_INT=NETMASK_INT[$2]
}
'

# Get an interface for a default gateway
unset IFACE
IFACE=`webif_defgw=$DEFGW awk "$PRG" /etc/network/interfaces`
if [[ x"$IFACE" = x"" ]]; then
    echo Wrong default gateway >&2
    exit 1
fi

PRG='
:start
/^iface[[:space:]]+__IFACE__/ b replace_defgw
/^iface/ b delete_defgw
b

:replace_defgw
a \
	gateway __DEFGW__
:_replace_defgw
n
/^#/ b _replace_defgw
/^iface[[:space:]]/ b start
/^[[:space:]]*gateway[[:space:]]/ d
b _replace_defgw

:delete_defgw
n
/^#/ b delete_defgw
/^iface[[:space:]]/ b start
/^[[:space:]]*gateway[[:space:]]/ d
b delete_defgw
'

PRG=`echo "$PRG" | sed -e "s/__IFACE__/$IFACE/; s/__DEFGW__/$DEFGW/"`

# Set a default gateway 
sed -i -re "$PRG" /etc/network/interfaces