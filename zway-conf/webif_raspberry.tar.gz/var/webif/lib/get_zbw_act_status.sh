#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#
#

if pgrep -x zbw_connect >/dev/null; then
    echo 1
else
    echo 0
fi

true
