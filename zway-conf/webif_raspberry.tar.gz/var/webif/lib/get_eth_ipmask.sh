#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#
# Env:
#  IFACE - interface name
#

if [[ x"$IFACE" = x"" ]]; then
    echo
    exit 0
fi

PRG='
BEGIN {
    IPMASK="";

    IF="";
}

END {
    print IPMASK;
}

/^iface/ {
    IF=$2;
}

IF == ENVIRON["IFACE"] && ! /^#/ && $1 == "netmask" {
    IPMASK=$2
}
'

awk "$PRG" /etc/network/interfaces