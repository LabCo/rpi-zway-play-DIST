#!/bin/bash
#
# Get:
#  $1 - parameter name
#  $2 - parameter type
#
# Env:
#  IFACE - interface name
#

if [[ x"$IFACE" = x"" ]]; then
    echo
    exit 0
fi

read IFMODE

if [[ $IFMODE -eq 0 ]]; then
    IFMODE="dhcp";
elif [[ $IFMODE -eq 1 ]]; then
    IFMODE="static";
fi

sed -i -re "s/^(iface[[:space:]]+$IFACE[[:space:]]+inet[[:space:]]+)[[:alnum:]]+$/\1$IFMODE/" /etc/network/interfaces