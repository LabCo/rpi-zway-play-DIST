#!/bin/bash

read VAL

config_lnk=/etc/webif.conf
dir=`pwd`/../config/
rdir=`readlink -f  $dir`
target=$rdir/webif_${VAL}.conf

if [ ! -e $target ]
then
	echo "File not found: $target"
	exit 1
fi

ln -fs $target $config_lnk
