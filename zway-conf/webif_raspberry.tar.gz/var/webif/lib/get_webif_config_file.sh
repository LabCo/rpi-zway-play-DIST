#!/bin/bash

path=`readlink /etc/webif.conf`
file=`basename $path`
part=${file%.conf}
lang=${part#webif_}
echo $lang
